<template>
  <div>企业产品信息组件</div>
</template>

<script>
export default {}
</script>

<style scoped lang="less">
</style>