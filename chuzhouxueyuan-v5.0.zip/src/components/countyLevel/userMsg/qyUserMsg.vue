<template>
  <div>企业用户管理组件</div>
</template>

<script>
export default {}
</script>

<style scoped lang="less">
</style>

