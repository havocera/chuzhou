<template>
  <div>溯源码扫描地查询组件</div>
</template>

<script>
export default {

}
</script>

<style scoped lang="less">

</style>

