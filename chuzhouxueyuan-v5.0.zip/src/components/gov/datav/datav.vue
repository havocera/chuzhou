<template>
  <datav />
</template>

<script>
import datav from './datav/index.vue'
export default {
    components:{
        datav
    }

}
</script>

<style>

</style>