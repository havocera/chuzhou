<template>
  <div>检测信息自动上传组件</div>
</template>

<script>
export default {

}
</script>

<style scoped lang="less">

</style>

