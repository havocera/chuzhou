<template>
  <div>农事作业信息组件</div>
</template>

<script>
export default {

}
</script>

<style scoped lang="less">

</style>

