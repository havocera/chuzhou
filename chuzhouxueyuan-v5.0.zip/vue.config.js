module.exports = {
    lintOnSave: false,
    devServer: {

        overlay: {

            warning: false,

            errors: false

        }

    },
}